// This file is deprecated. Using utils/supabase.ts instead.
export const auth = null;
export const db = null;
export const googleProvider = null;
